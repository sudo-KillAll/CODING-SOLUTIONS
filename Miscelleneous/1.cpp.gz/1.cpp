#include<bits/stdc++.h>

#define ll long long int
#define pb push_back
#define f first
#define s second
#define vi vector<ll>
#define mi map<ll,ll>
#define forn(n) for(ll i=0;i<n;i++)
#define mi map<ll,ll>
#define print(v) for(ll printing=0;printing<v.size();printing++){cout<<v[printing]<<' ';}
#define TestCase ll testcase;cin>>testcase;while(testcase--)
#define bin(n) bitset<32>(n).to_string();
#define max(v) *max_element(v.begin(),v.end())
#define min(v) *min_element(v.begin(),v.end())
using namespace std;
void solve(){
    ll n;cin>>n;
    ll res=0;
    while(n>0){
        
    }
    
    if(res!=s)
        cout<<"FEELS GOOD"<<"\n";
    else
        cout<<"FEELS BAD"<<"\n";
}

int main(){
ios_base::sync_with_stdio(false); 
cin.tie(NULL);
cout.tie(NULL);
TestCase
    solve();
}