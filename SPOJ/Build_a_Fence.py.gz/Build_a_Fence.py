pi = 3.141592654
while(True):
    n=int(input())
    if(n==0):
        break
    else:
        print(round((n*n)/(2*pi),2))