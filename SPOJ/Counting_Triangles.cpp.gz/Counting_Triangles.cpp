#include<bits/stdc++.h>
using namespace std;
int main(){
long long int t;cin>>t;
while(t--){
    long long int n;cin>>n;
    long long int ans=(2*(n*(n-1)))+1;
    cout<<ans<<"\n";
}
} 