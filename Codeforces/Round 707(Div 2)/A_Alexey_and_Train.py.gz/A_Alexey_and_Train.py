for _ in range(int(input())):
    n=int(input())
    