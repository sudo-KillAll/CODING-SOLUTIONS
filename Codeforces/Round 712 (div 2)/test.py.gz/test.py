import subprocess
p1 = subprocess.run(["g++", "test.cpp"]);

print(p1)