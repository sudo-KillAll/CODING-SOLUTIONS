s=input()
s+=s[0]
print(s[1:])