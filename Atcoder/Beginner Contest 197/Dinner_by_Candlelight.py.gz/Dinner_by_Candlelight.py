for _ in range(int(input())):
    a,y,x=[int(i) for i in input().split()]
    print(max(a,y)*x)